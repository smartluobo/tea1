const formatTime = date => {
  const year = date.getFullYear()
  const month = date.getMonth() + 1
  const day = date.getDate()
  const hour = date.getHours()
  const minute = date.getMinutes()
  const second = date.getSeconds()

  return [year, month, day].map(formatNumber).join('/') + ' ' + [hour, minute, second].map(formatNumber).join(':')
}

const formatNumber = n => {
  n = n.toString()
  return n[1] ? n : '0' + n
}
function parseQueryString(url) {
  var items = url.split("&"),obj={};
  var arr, name, value;
  for (var i = 0, l = items.length; i < l; i++) {
    arr = items[i].split("=");
    name = arr[0];
    value = arr[1];
    obj[name] = value;
  };
  return obj;
}
const queryRegion = (response) => {
  var regex = /^(北京市|天津市|重庆市|上海市|香港特别行政区|澳门特别行政区)/;
  var region_province = [];
  var addressBean = {
    region_province: null,
    region_city: null,
    region_district: null,
  };
  if (!response.address) {
    return null;
  }
  function regexAddressBean(address, addressBean) {
    regex = /^(.*?[市州]|.*?地区|.*?特别行政区)(.*?[市区县])(.*?)$/g;
    var addxress = regex.exec(address);
    addressBean.region_city = addxress[1];
    addressBean.region_district = addxress[2];
  }
  if (!(region_province = regex.exec(response.address))) {
    regex = /^(.*?(省|自治区))(.*?)$/;
    region_province = regex.exec(response.address);
    if (region_province) {
      addressBean.region_province = region_province[1];
      regexAddressBean(region_province[3], addressBean);
    } else {
      return null;
    }
  } else {
    addressBean.region_province = region_province[1];
    regexAddressBean(response.address, addressBean);
  }
  return addressBean;
}

const formateDate = (date,flag) =>{
  var year = date.getFullYear();
  var month = date.getMonth() + 1;
  var day = date.getDate();
  var hour = date.getHours();
  var minute = date.getMinutes();
  var second = date.getSeconds();
  var mm = date.getTime() % 1000;
  if(month < 10){
    month = "0" + month;
  }
  if(day < 10){
    day = "0" + day
  }
  if(hour < 10){
    hour = "0" + hour
  }
  if(minute < 10){
    minute = "0" + minute
  }
  if(second < 10){
    second = "0" + second
  }
  if(flag){
    return year+"-"+month+"-"+day+" "+hour+":"+minute+":"+second
  }else{
    return  year+"-"+month+"-"+day
  }
}

const isEmptyStr = (str) =>{
  if(str == null || typeof str == "undefined" || str == ""){
    return true;
  }else{
    return false;
  }
}
module.exports = {
  formatTime: formatTime,
  parseQueryString: parseQueryString,
  queryRegion: queryRegion,
  formateDate:formateDate,
  isEmptyStr:isEmptyStr

}
