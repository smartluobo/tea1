import { parseQueryString } from "../../utils/util";
const app = getApp();
Page({
  /**
   * 页面的初始数据
   */
  data: {
    shoplist: [],
    shopName: "",
    page: { pageNo: 0, pageSize: 100 },
    token: wx.getStorageSync("token"),
    show: true,
    nolist: false,
    isScanCode: false,
    isConnected: true
  },
  filterShop: function (e) {
    console.log(e);
    this.setData({
      shopName: e.detail.value.trim(),
    });
    this.getShopList();
  },
  toSearch: function (e) {
    wx.navigateTo({
      url: '/pages/searchresult/index'
    })
  },
  scantoactive: function () {
    var that = this;
    that.setData({ isScanCode: true });
    // 只允许从相机扫码，不能相册扫码
    wx.scanCode({
      onlyFromCamera: true,
      success: (res) => {
        var path = parseQueryString(res.result);
        var type = path.type;//二维码参数 type active激活设备 tosign签到
        delete path.type;
        if (type == "tosign") {
          wx.request({
            url: app.globalData.hostUrl + '3m/signin/signin',
            data:
            {
              deviceNum: path.deviceNum,
              validTime: path.validTime,
              token: wx.getStorageSync("token")
            }
            ,
            success: function (res) {
              that.setData({ isScanCode: false });
              if (res.data) {
                var signed = "";
                if (res.data.status == 203) {
                  //二维码失效
                  wx.showToast({
                    title: '二维码已失效！',
                    icon: "error",
                    duration: 1500
                  });
                  return;
                }
                if (res.data.status == 200) {
                  wx.navigateTo({
                    url: '../sign/index?res=' + JSON.stringify(res.data.data)
                  })
                } else if (res.data.status == 305) {
                  signed = 0;
                  wx.navigateTo({
                    url: '../sign/index?signed=' + signed + '&res=' + JSON.stringify({})
                  })
                  // wx.showToast({
                  //   title: '该设备今日已签到',
                  //   icon: "none",
                  //   duration: 1500
                  // })
                }

              }
            },
            fail: function () {
              that.setData({ isScanCode: false });
              wx.showToast({
                title: '无法识别二维码,请稍后重试！',
                icon: "none",
                duration: 1500
              })
            }
          })
        } else {
          that.setData({ isScanCode: false });
          wx.showToast({
            title: '无法识别二维码！',
            icon: "none",
            duration: 1500
          })
        }
      },
      fail: function (e) {
        /*
        wx.showToast({
          title: '无法识别二维码！',
          icon: "none",
          duration: 1500
        })
        */
      },
      complete: function () {
        console.log('scan complete');
      }
    })
  },
  getShopList: function () {
    var that = this;
    wx.showToast({
      title: '加载中',
      icon: "loading"
    })
    wx.request({
      url: app.globalData.hostUrl + '3m/shopInfo/list',
      data: {
        token: wx.getStorageSync("token"),
        page: that.data.page,
        shopName: that.data.shopName
      },
      method: 'post',
      success: function (res) {
        if (res.data && res.data.status == 200) {
          var shoplist = res.data.data.data;
          for (var i = 0; i < shoplist.length; i++) {
            shoplist[i].region = shoplist[i].region.replace(/,/g, '');
          }
          that.setData({
            shoplist: shoplist,
            nolist: (shoplist.length == 0)
          })
        }
      },
      complete: function () {
        wx.hideToast();  //隐藏Toast
      }
    })
  },
  toShop: function (e) {
    var id = e.currentTarget.dataset.index;
    console.log(id);
    wx.navigateTo({
      url: '/pages/shopdetail/index?id=' + id
    })
  },
  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    this.getNetworkTypeInfo();
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {
    var sessionId = wx.getStorageSync('token');
    var newUrl = '/pages/checkphone/index';
    var that = this;
    if (!sessionId) {
      // 登录
      wx.login({
        success: res => {
          // 发送 res.code 到后台换取 openId, sessionKey, unionId
          wx.request({
            url: app.globalData.hostUrl + '3m/login/getOpenid',
            data: {
              code: res.code,
              type: app.globalData.type
            },
            success: function (res) {
              if (res.data && res.data.status == 200) {
                //执行成功
                app.globalData.openid = res.data.data;
                wx.setStorageSync('openid', res.data.data);
                wx.redirectTo({
                  url: newUrl
                });
              }
            }
          })
        }
      })
    } else {
      that.setData({
        show: false
      })
      if (!that.data.isScanCode) {
        that.getShopList();
      } else {
        that.setData({
          isScanCode: false
        })
      }
    }
  },

  getNetworkTypeInfo: function () {
    var that = this;
    wx.getNetworkType({
      success(res) {
        const networkType = res.networkType
        if (networkType == 'none') {
          that.setData({ isConnected: false });
        } else {
          that.setData({ isConnected: true });
        }
      },
      fail(res) {
        that.setData({ isConnected: false });
      }
    })
    wx.onNetworkStatusChange(function (res) {
      that.setData({ isConnected: res.isConnected })
      if (res.isConnected) {
        that.getShopList();
      }
    })
  }
})
