// pages/active/index.js
const app = getApp();
Page({

  /**
   * 页面的初始数据
   */
  data: {
    deviceName:'',
    params:{},
    isScanCode:false
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    if(options.params){
      var params = JSON.parse(options.params);
      this.setData({params:params})
    }
  },

  deviceChangeHandle:function(e) {
    this.setData({
      deviceName: e.detail.value
    })
  },

  confirmActiveHandle:function(){
    var that = this;
    var isScanCode = this.data.isScanCode;
    var params = this.data.params;
    var deviceName = this.data.deviceName;
    params.deviceName = deviceName;
    if(!deviceName){
      wx.showToast({
        title: '请输入设备名称',
        icon: 'none',
        duration: 2000
      })
    }
    if(isScanCode){
      return;
    }
    that.setData({ isScanCode: true });
    wx.request({
      url: app.globalData.hostUrl + '3m/signin/activateDevice',
      data: params,
      success: function (res) {
        console.log("success");
        if (res.data && res.data.status == 200) {
          that.setData({ isScanCode: false });
          wx.redirectTo({
            url: '../active/index?res=' + JSON.stringify(res.data.data)
          })
        }
      },
      fail: function (res) {
        console.log(res);
      }
    })
  }
})
