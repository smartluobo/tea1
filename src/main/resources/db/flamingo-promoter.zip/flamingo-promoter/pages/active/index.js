// pages/active/index.js
Page({

  /**
   * 页面的初始数据
   */
  data: {
    num :"",
    activeInfo:{}
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    if(options.res){
      this.setData({
        activeInfo:JSON.parse(options.res)
      });
    }
    wx.showToast({
      title: '激活成功',
      icon:"success",
      duration: 1500
    })
  },
  closeHandle:function(){
    wx.navigateBack({
      delta: 1
    })
  }
})
