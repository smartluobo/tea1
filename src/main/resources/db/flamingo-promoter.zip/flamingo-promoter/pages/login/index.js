//index.js
//获取应用实例
const app = getApp();
Page({
  data: {
    phoneNum:"",
    codeNum:"",
    btnTxt :"获取验证码",
    btnDisabled:true,
    errorInfo: '',
    userInfo: {},
    hasUserInfo: false,
    canIUse: wx.canIUse('button.open-type.getUserInfo')
  },
  //事件处理函数
  bindViewTap: function() {
    wx.navigateTo({
      url: '../logs/logs'
    })
  },
  //输入手机号事件处理
  bindPhoneInput: function(e){
    this.setData({
      phoneNum: e.detail.value.trim(),
      errorInfo:""
    })
  },
  //输入验证码事件处理
  bindCodeInput: function (e){
    this.setData({
      codeNum: e.detail.value.trim(),
      errorInfo: ""
    })
  },
  delPhone :function(){
    this.setData({
      phoneNum: "",
      errorInfo: ""
    })
  },
   //获取验证码
  getCode: function(){
    if (this.data.btnDisabled) return;
    console.log(this.data.btnDisabled);
    var that = this;
    that.setData({
      btnDisabled: true
    })
    this.sentCode();
    //发送验证码
    wx.request({
      url: app.globalData.hostUrl + 'mcm/sendSms/verifyCode', //仅为示例，并非真实的接口地址
      data: {
        phoneNum: that.data.phoneNum
      },
      success: function (res) {
        if (res.data && res.data.status == 200 && res.data.data.errcode == 0) {
        //if (res.status == 200) {
          //执行成功
          wx.showToast({
            title: '已发送短信',
            icon: 'none',
            duration: 1500
          })
        }
      }
    })
  },
  /**
   * 发送验证码
   */
  sentCode : function(){
    var that = this;
    var countdown = 59,codeTxt = "";
    var codeTimer = setInterval(function(){
      if(countdown == 0){
        that.setData({
          btnTxt: "点击获取",
          btnDisabled: false
        });
        clearInterval(codeTimer);
      }else{
        that.setData({
          btnTxt: "重新发送 (" + (countdown--) + "S)",
          btnDisabled: true
        })
      }
    },1000)
  },

  toLogin: function(){
    var that = this;
    if (that.data.phoneNum.length == 0 || that.data.codeNum.length == 0) {
      return;
    }
    wx.showToast({
      title: '登录中',
      icon: 'loading',
      duration:1500
    });
    //登陆后台
    wx.request({
      url: app.globalData.hostUrl + '3m/login/login',
      data: {
        phoneNumber: that.data.phoneNum,
        verifiedCode: that.data.codeNum,
        openid: wx.getStorageSync('openid'),
        type: app.globalData.type //1.商户 2.地推用户
      },
      success: function (res) {
        if (res.data && res.data.status == 200) {
          //执行成功
          wx.setStorageSync('token', res.data.data);
          wx.setStorageSync('phone', that.data.phoneNum);
          wx.switchTab({
            url: '../shoplist/index'
          });
        }else if(res.data && res.data.status == 201){
          wx.showToast({
            title: '验证码已过期',
            icon: "none",
            duration: 1500
          })
        }else{
          wx.showToast({
            title: '验证码不正确，请重新输入',
            icon: "none",
            duration: 1500
          })
        }
      }
    })
  },
  onLoad: function (options) {
    wx.showToast({
      title: '已发送短信',
      icon: 'none',
      duration: 1500
    })
    this.sentCode();
    var phone = options.phone;
    var userInfo = "";
    if (app.globalData.userInfo) {
      userInfo = app.globalData.userInfo;
    } else if (this.data.canIUse){
      // 由于 getUserInfo 是网络请求，可能会在 Page.onLoad 之后才返回
      // 所以此处加入 callback 以防止这种情况
      app.userInfoReadyCallback = res => {
        userInfo = res.userInfo
      }
    } else {
      // 在没有 open-type=getUserInfo 版本的兼容处理
      wx.getUserInfo({
        success: res => {
          app.globalData.userInfo = res.userInfo
        }
      })
    }
    this.setData({
      userInfo: userInfo,
      hasUserInfo: true,
      phoneNum: phone
    })
  },
  getUserInfo: function(e) {
    app.globalData.userInfo = e.detail.userInfo
  }
})
