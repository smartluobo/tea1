// pages/newshop/index.js
import { queryRegion } from "../../utils/util"
const app = getApp();
Page({
  data: {
    submiting: false,
    id: "",
    uploading: false,
    regionCode: "000000",
    region: [],
    mainEntrance: '',
    isWifi: '',
    devicePosition: '',
    installType: '',
    playType: '',
    skNature: '',
    trade: '',
    images: [],
    shopStatus: ["未激活", "投放中", "已激活"],
    shopCat: [],
    entranceset: ["非主出入口", "商场主出入口", "社区主出入口", "街道主出入口"],
    wifiset: ["有", "无"],
    devpoiset: ["店铺内", "店铺外", "店铺内和店铺外"],
    devinsset: ["挂装", "吊装", "坐装", "落地支架坐装"],
    devplayset: ["广告", "广告和店铺内容"],
    devtypeset: ["社区", "商圈", "校园"],
    tipInfo: {
      name: "店铺名称", region: "店铺所在地区", regionCode: "地区编码", doorNum: "门牌号", address: "店铺详细地址", businessLicense: " 营业执照", businessTime: "营业时间", skName: "店主姓名", skPhone: "店主电话", isWifi: "WIFI网络", devicePosition: "设备摆放位置", deviceNums: "设备台数", installType: "设备安装方式", installTime: "装机时间", openPeriod: "预约开机时段", openDuration: "预约开机时长单位", images: "店铺照片", corporation: "法人代表", cardId: "法人代表身份证号", deposit: "店铺押金 (单位元)", bankAccount: "银行卡号", accountName: "银行户名", openingBank: "开户银行", deposit: "店铺押金 (单位元)"
    },
    firstLinkupTime: '',
    confirmTime: '',
    installTime: '',
    businessTime: [],
    peakPeriod: [],
    openPeriod: [],
    skNativePlace: [],
    skNativePlaceText: '',
    isModalHidden: true,
    isAndroid: true,
    blankInfo: {}
  },
  formSubmit: function (e) {
    var that = this;

    var formdata = e.detail.value;

    for (var name in formdata) {
      if (that.data.tipInfo[name]) {
        if (formdata[name] === "" || formdata[name] === undefined || (Array.isArray(formdata[name]) && formdata[name].length === 0)) {
          wx.showToast({
            title: "请输入" + that.data.tipInfo[name] + "!",
            icon: "none",
            duration: 1500
          });
          return;
        } else if (name.search(/businessTime|peakPeriod|openPeriod/i) != -1) {
          if (that.data[name].length == 0) {
            wx.showToast({
              title: "请输入" + that.data.tipInfo[name] + "!",
              icon: "none",
              duration: 1500
            });
            return;
          }
        }
      }
    };
    var imageList = that.data.images;
    if (Array.isArray(imageList) && imageList.length == 0) {
      wx.showToast({
        title: "请上传店铺照片!",
        icon: "none",
        duration: 1500
      });
      return;
    };
    var timeArray = that.data.timeArray;
    var businessTime = that.data.businessTime;
    var openPeriod = that.data.openPeriod;
    var peakPeriod = that.data.peakPeriod;
    console.log(that.data.trade)
    var vset = Object.assign({}, e.detail.value, {
      region: that.data.region.join(","),
      images: that.data.images.join(","),
      latitude: that.data.coor.split(",")[0],
      longitude: that.data.coor.split(",")[1],
      regionCode: that.data.regionCode,
      trade: that.data.trade && that.data.trade >= 0 ? that.data.shopCat[that.data.trade]['name'] : "",
      skNativePlace: that.data.skNativePlace ? that.data.skNativePlace.join(',') : "",
      businessTime: timeArray && timeArray.length > 0 && businessTime && businessTime.length > 0 ? timeArray[0][businessTime[0]] + ':' + timeArray[1][businessTime[1]] + '到' + timeArray[2][businessTime[2]] + ':' + timeArray[3][businessTime[3]] : "",
      openPeriod: timeArray && timeArray.length > 0 && openPeriod && openPeriod.length > 0 ? timeArray[0][openPeriod[0]] + ':' + timeArray[1][openPeriod[1]] + '到' + timeArray[2][openPeriod[2]] + ':' + timeArray[3][openPeriod[3]] : "",
      peakPeriod: timeArray && timeArray.length > 0 && peakPeriod && peakPeriod.length > 0 ? timeArray[0][peakPeriod[0]] + ':' + timeArray[1][peakPeriod[1]] + '到' + timeArray[2][peakPeriod[2]] + ':' + timeArray[3][peakPeriod[3]] : ""
    })

    delete vset.coor;
    if (that.data.submiting) {
      return;
    }
    that.setData({
      submiting: true
    });

    //新建店铺
    wx.request({
      url: app.globalData.hostUrl + '3m/shopInfo/save',
      data: {
        shopInfo: vset,
        token: wx.getStorageSync("token")
      },
      success: function (res) {
        if (res.data && res.data.status == 200) {
          wx.showToast({
            title: '创建成功',
            icon: "success",
            duration: 1500,
            success: function () {
              setTimeout(() => {
                wx.navigateBack({
                  delta: 1
                })
              }, 1500)
            }
          })
        } else {
          wx.showToast({
            title: '请求失败，请稍后重试！',
            icon: "none",
            duration: 1500
          });
          that.setData({
            submiting: false
          })
        }
      },
      fail: function () {
        wx.showToast({
          title: '请求失败，请稍后重试！',
          icon: "none",
          duration: 1500,
        });
        that.setData({
          submiting: false
        })
      },
      complete: function () {
        /*
        that.setData({
          submiting: false
        })
        */
      }
    })
  },
  getShopCat: function () {
    var that = this;
    wx.request({
      url: app.globalData.hostUrl + '3m/shopInfo/getTrade',
      data: {
        token: wx.getStorageSync("token")
      },
      success: function (res) {
        if (res.data && res.data.status == 200) {
          that.setData({
            shopCat: res.data.data
          })
        }
      }
    })
  },
  bindCatChange: function (e) {
    var names = e.currentTarget.dataset.relate;
    var obj = {};
    obj[names] = e.detail.value;
    this.setData(obj);
  },
  chooseImage: function (event) {
    var that = this;
    if (that.data.uploading) {
      wx.showToast({
        title: '图片上传中，请稍后重试！',
        icon: "none",
        duration: 1500
      });
      return;
    }
    if (this.data.images.length >= 3) {
      wx.showToast({
        title: '最多上传三张照片哦！',
        icon: "none",
        duration: 1500
      });
      return;
    }
    var photoNum = 3 - this.data.images.length;
    wx.chooseImage({
      count: photoNum, // 一次最多可以选择3张图片一起上传
      sizeType: ['original', 'compressed'], // 可以指定是原图还是压缩图，默认二者都有
      sourceType: ['album', 'camera'], // 可以指定来源是相册还是相机，默认二者都有
      success: function (res) {
        that.setData({
          uploading: true,
          imagePaths: res.tempFilePaths
        });
        that.uploadImgs(that, res.tempFilePaths)
      }
    })
  },
  delimg: function (event) {
    var id = event.currentTarget.dataset.id;
    var imagelist = this.data.images;
    imagelist.splice(id, 1);
    this.setData({
      images: imagelist
    })
  },
  previewImage: function (e) {
    var that = this;
    var dataid = e.currentTarget.dataset.id;
    wx.previewImage({
      current: that.data.images[dataid],
      urls: that.data.images
    });
  },

  uploadImgs: function (page, paths) {
    wx.showToast({
      icon: "loading",
      title: "正在上传"
    });
    this.uploadFile(paths, 0);
  },

  uploadFile: function (paths, index) {
    var that = this;
    var imagePaths = that.data.imagePaths;
    if (imagePaths.length == index) {
      wx.hideToast();  //隐藏Toast
      return;
    }
    wx.uploadFile({
      url: app.globalData.hostUrl + "3m/shopInfo/upload",
      filePath: paths[index],
      name: 'file',
      header: { "Content-Type": "multipart/form-data" },
      formData: {
        //和服务器约定的token, 一般也可以放在header中
        'token': wx.getStorageSync('token')
      },
      success: function (res) {
        if (res.statusCode != 200) {
          wx.showModal({
            title: '提示',
            content: '上传失败',
            showCancel: false
          })
          return;
        }
        var data = JSON.parse(res.data), image = that.data.images || [];
        image.push(data.data.url);
        that.setData({
          images: image,
          uploading: false
        })
        that.uploadFile(paths, index + 1);
      },
      fail: function (e) {
        wx.showModal({
          title: '提示',
          content: '上传失败',
          showCancel: false
        });
        that.setData({
          uploading: false
        })
        that.uploadFile(paths, index);
      }
    })
  },


  bindRegionChange: function (e) {
    this.setData({
      region: e.detail.value,
      areaCode: e.detail.code[2]
    })
  },
  getCurLocation: function () {
    var that = this;
    // 获取当前位置
    wx.getLocation({
      type: "gcj02",
      success: function (res) {
        //name 名称 address 地址
        var latitude = res.latitude;
        var longitude = res.longitude;
        wx.chooseLocation({
          latitude: latitude,
          longitude: longitude,
          success: function (response) {
            var data = {
              latitude: response.latitude,
              longitude: response.longitude,
              address: response.name

            }
            var addressBean = queryRegion(response);
            if (addressBean) {
              data.region = [addressBean.region_province, addressBean.region_city, addressBean.region_district];
            }
            if (response.latitude) {
              data.coor = response.latitude.toFixed(5) + ',' + response.longitude.toFixed(5);
            }
            that.setData(data);
          }
        })
      },
      fail: function (res) {
        console.log(res);
        that.setData({ isModalHidden: false });
      }
    })
  },
  bindDateChangeFirst: function (e) {
    var arr = e.detail.value.split('-');
    this.setData({
      firstLinkupTime: e.detail.value,
      firstLinkupTimeStr: arr[0] + '年' + arr[1] + '月' + arr[2] + '日',
    })
  },
  bindDateChangeConfirm: function (e) {
    var arr = e.detail.value.split('-');
    this.setData({
      confirmTime: e.detail.value,
      confirmTimeStr: arr[0] + '年' + arr[1] + '月' + arr[2] + '日',
    })
  },
  bindDateChangeInstall: function (e) {
    var arr = e.detail.value.split('-');
    this.setData({
      installTime: e.detail.value,
      installTimeStr: arr[0] + '年' + arr[1] + '月' + arr[2] + '日',
    })
  },
  bindBTimeChange: function (e) {
    var time = this.checkTimeRange(e.detail.value);
    if (time) {
      this.setData({
        businessTime: time
      })
    }
  },
  bindPeakPeriodChange: function (e) {
    var time = this.checkTimeRange(e.detail.value);
    if (time) {
      this.setData({
        peakPeriod: time
      })
    }
  },
  bindOpenPeriodChange: function (e) {
    var time = this.checkTimeRange(e.detail.value);
    if (time) {
      this.setData({
        openPeriod: time
      })
    }
  },
  bindskNativePlaceChange: function (e) {
    var arr = e.detail.value;
    var skNativePlaceText = arr[0] + arr[1];
    if (arr[0].search(/北京市|上海市|天津市|重庆市/i) != -1) {
      skNativePlaceText = arr[0] + arr[2];
    }
    this.setData({
      skNativePlace: arr,
      skNativePlaceText: skNativePlaceText
    })
  },
  handleInput: function (e) {
    var obj = {};
    obj[e.target.dataset.name] = e.detail.value;
    this.setData(obj)
  },
  newHours: function () {
    var arr = [];
    for (var i = 0; i < 24; i++) {
      if (i < 10) {
        arr.push('0' + i);
      } else {
        arr.push('' + i);
      }
    }
    return arr;
  },
  newMinutes: function () {
    var arr = [];
    for (var i = 0; i < 60; i++) {
      if (i < 10) {
        arr.push('0' + i);
      } else {
        arr.push('' + i);
      }
    }
    return arr;
  },
  checkTimeRange: function (time) {
    if (time[0] > time[2]) {
      wx.showToast({
        title: "开始时间不能晚于结束时间",
        icon: 'none',
        duration: 1500
      });
      return false;
    } else if (time[0] == time[2] && time[1] >= time[3]) {
      wx.showToast({
        title: "开始时间不能晚于结束时间",
        icon: 'none',
        duration: 1500
      });
      return false;
    }
    return time;
  },
  preventTouchMove: function (evt) {

  },
  hideModal: function () {
    this.setData({
      isModalHidden: true
    });
  },

  getBlankInfoByPhoneNum: function (phone) {
    var that = this;
    wx.request({
      url: app.globalData.hostUrl + '3m/shopInfo/bankInfo',
      data: {
        phoneNum: phone,
        token: wx.getStorageSync("token")
      },
      success: function (res) {
        if (res.data && res.data.status == 200) {
          that.setData({
            blankInfo: res.data.data
          })
        }
      }
    })
  },

  blurHandle: function (e) {
    var phone = e.detail.value;
    this.getBlankInfoByPhoneNum(phone)
  },

  /**
  * 生命周期函数--监听页面加载
  */
  onLoad: function (options) {
    this.getShopCat();
    wx.getSystemInfo({
      success: (res) => {
        if (res.platform == 'ios') {
          this.setData({
            isAndroid: false
          });
        }
      }
    });
    this.setData({
      timeArray: [this.newHours(), this.newMinutes(), this.newHours(), this.newMinutes()]
    });
  }
})
