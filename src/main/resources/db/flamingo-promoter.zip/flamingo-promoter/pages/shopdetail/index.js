// pages/newshop/index.js
import { parseQueryString } from "../../utils/util";
const app = getApp();
Page({
  data: {
    id: "",
    shopStatus: ["未激活", "投放中", "已激活"],
    shopCat: [],
    entranceset: ["非主出入口", "商场主出入口", "社区主出入口", "街道主出入口"],
    wifiset: ["有", "无"],
    devpoiset: ["店铺内", "店铺外", "店铺内和店铺外"],
    devinsset: ["挂装", "吊装", "坐装", "落地支架坐装"],
    devplayset: ["广告", "广告和店铺内容"],
    devtypeset: ["社区", "商圈", "校园"],
    isAndroid: true,
    isScanCode: false,
    starTxt: ["非常不满意，极差", "不满意，比较差", "一般，还需改善", "比较满意，仍可改善", "非常满意，无可挑剔"]
  },
  /**
   * 生命周期函数--监听页面加载
   */
  gotoedit: function () {
    wx.navigateTo({
      url: '/pages/editshop/index?id=' + this.data.id
    })
  },
  activedevice: function () {
    var that = this;
    that.setData({ isScanCode: true });
    // 允许从相机和相册扫码
    wx.scanCode({
      onlyFromCamera: true,
      success: (res) => {
        var path = parseQueryString(res.result);
        var types = path.type;//二维码参数 type active激活设备 tosign签到
        delete path.type;
        if (types == "active") {
          var data = Object.assign({}, path,
            {
              sId: that.data.id,
              token: wx.getStorageSync("token")
            }
          )

          wx.navigateTo({
            url: '/pages/activedevice/activedevice?params=' + JSON.stringify(data)
          })

        } else {
          wx.showToast({
            title: '无法识别二维码！',
            icon: "none",
            duration: 1500
          })
        }
      },
      fail: function () {
        /*
        wx.showToast({
          title: '无法识别二维码！',
          icon: "none",
          duration: 1500
        })
        */
      }
    })
  },
  onLoad: function (options) {
    this.getShopCat();
    this.setData({
      sid: options.id
    });
    wx.getSystemInfo({
      success: (res) => {
        if (res.platform == 'ios') {
          this.setData({
            isAndroid: false
          });
        }
      }
    });
  },
  getShopCat: function () {
    var that = this;
    wx.request({
      url: app.globalData.hostUrl + '3m/shopInfo/getTrade',
      data: {
        token: wx.getStorageSync("token")
      },
      success: function (res) {
        if (res.data && res.data.status == 200) {
          var trade = that.data.trade;
          var obj = {
            shopCat: res.data.data,
          }
          if (trade == -1) {
            if (isNaN(parseInt(that.data.tradeText))) {
              trade = res.data.data.findIndex((item) => {
                return that.data.tradeText == item.name;
              })
              obj.trade = trade;
            }
          }
          that.setData(obj)
        }
      }
    })
  },
  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {
    var that = this;
    if (that.data.isScanCode) {
      that.setData({
        isScanCode: false
      })
      return;
    }
    wx.showLoading({
      title: '加载中',
    })
    wx.request({
      url: app.globalData.hostUrl + '3m/shopInfo/findById',
      data: {
        id: that.data.sid,
        token: wx.getStorageSync("token")
      },
      success: function (res) {
        if (res.data && res.data.status == 200) {
          var detailinfo = res.data.data;
          var installTimeStr = '';
          var firstLinkupTimeStr = '';
          var confirmTimeStr = '';
          if (detailinfo.installTime) {
            var installTime = detailinfo.installTime.split('-');
            installTimeStr = installTime[0] + '年' + installTime[1] + '月' + installTime[2] + '日';
          }
          if (detailinfo.firstLinkupTime) {
            var firstLinkupTime = detailinfo.firstLinkupTime.split('-');
            firstLinkupTimeStr = firstLinkupTime[0] + '年' + firstLinkupTime[1] + '月' + firstLinkupTime[2] + '日';
          }
          if (detailinfo.confirmTime) {
            var confirmTime = detailinfo.confirmTime.split('-');
            confirmTimeStr = confirmTime[0] + '年' + confirmTime[1] + '月' + confirmTime[2] + '日';
          }
          var skNativePlace = '';
          if (detailinfo.skNativePlace) {
            var arr = detailinfo.skNativePlace.split(',');
            if (arr.length == 3) {
              skNativePlace = arr[0] + arr[1];
              if (arr[0].search(/北京市|上海市|天津市|重庆市/i) != -1) {
                skNativePlace = arr[0] + arr[2];
              }
            }
          }
          var trade = detailinfo.trade;
          if (isNaN(parseInt(detailinfo.trade))) {
            trade = that.data.shopCat.findIndex((item) => {
              return trade == item.name;
            })
          }
          var newObj = Object.assign({}, detailinfo, {
            id: that.data.sid,
            region: detailinfo.region.split(",") || [],
            coor: detailinfo.latitude + "," + detailinfo.longitude,
            installTimeStr: installTimeStr,
            firstLinkupTimeStr: firstLinkupTimeStr,
            confirmTimeStr: confirmTimeStr,
            skNativePlace: skNativePlace,
            trade: trade,
            tradeText: detailinfo.trade,
            images: (detailinfo.images && detailinfo.images.split(",")) || []
          });
          detailinfo.region = detailinfo.region.replace(/,/g, '');
          that.setData({
            detailinfo: detailinfo,
            ...newObj
          })
        }
        wx.hideLoading()
      },
      fail: function () {
        wx.hideLoading()
      }
    });
  },

  shopMapHandle: function () {
    var detailinfo = this.data.detailinfo;
    var latitude = detailinfo.latitude;
    var longitude = detailinfo.longitude;
    wx.openLocation({
      longitude: Number(longitude),
      latitude: Number(latitude),
      name: detailinfo.name,
      address: detailinfo.region + detailinfo.address
    })
    
  }
})
