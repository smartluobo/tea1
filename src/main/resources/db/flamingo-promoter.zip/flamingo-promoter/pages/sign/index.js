// pages/sign/index.js
import { formatTime } from "../../utils/util"
Page({

  /**
   * 页面的初始数据
   */
  data: {
    num: "",
    hidden: false,
    signInfo: {},
    signed: ''
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    if (options.res) {
      this.setData({
        signInfo: JSON.parse(options.res)
      });
    }
    if (options.signed) {
      this.setData({ signed: options.signed });
      wx.showToast({
        title: '该设备今日已签到',
        icon: "none",
        duration: 1500
      })
    } else {
      wx.showToast({
        title: '签到成功',
        icon: "success",
        duration: 1500
      })
    }
  },

  closeHandle: function () {
    wx.navigateBack({
      delta: 1
    })
  }
})
