// pages/checkphone/index.js
const app = getApp();
Page({

  /**
   * 页面的初始数据
   */
  data: {
    phone: "",
    asking: false
  },
  bindPhoneInput: function (e) {
    this.setData({
      phone: e.detail.value.trim(),
      asking: false
    })
  },
  checkPhone: function () {
    var that = this;
    if (that.data.phone.length == 0) {
      return;
    }
    if (that.data.asking) {
      return;
    }
    var phoneReg = /(^1[3|4|5|7|8]\d{9}$)|(^09\d{8}$)/;
    var phoneNum = this.data.phone;
    if (!phoneReg.test(phoneNum)) {
      wx.showToast({
        title: '请输入正确的11位手机号！',
        icon: "none",
        duration: 1500
      })
      return;
    }
    //验证有效手机号 type 1商户2地推用户
    this.setData({
      asking: true
    });
    wx.request({
      url: app.globalData.hostUrl + '3m/login/checkPhoneNumber',
      data: {
        phoneNumber: phoneNum,
        type: app.globalData.type
      },
      success: function (res) {
        if (res.data && res.data.status == 200) {
          //发送验证码
          wx.request({
            url: app.globalData.hostUrl + 'mcm/sendSms/verifyCode',
            data: {
              phoneNum: phoneNum
            },
            success: function (res) {
              if (res.data && res.data.status == 200 && res.data.data.errcode == 0) {
                //执行成功
                wx.redirectTo({
                  url: '/pages/login/index?phone=' + phoneNum,
                });
              }
            }
          })
        }
        else {
          that.setData({
            asking: false
          });
          wx.showToast({
            title: '请输入营销人员手机号',
            icon: "none",
            duration: 1500
          })
        }
      },
      complete: function () {
      }
    })
  },
  delPhone: function () {
    this.setData({
      phone: ""
    })
  }
})