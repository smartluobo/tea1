const app = getApp();
Page({

  /**
   * 页面的初始数据
   */
  data: {
    id: "",
    shopInfo: {},
    devicelist: []
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    var sid = options.id;
    var signDate = options.signDate;
    var that = this;
    wx.showLoading();
    wx.request({
      url: app.globalData.hostUrl + '3m/signin/shopDeviceSignin',
      data: {
        sId: sid,
        token: wx.getStorageSync("token"),
        signDate: signDate
      },
      success: function (res) {
        if (res.data && res.data.status == 200) {
          var arr = res.data.data.devices;
          var shopInfo = res.data.data;
          for (var i = 0; i < arr.length; i++) {
            if (arr[i].signinTime) {
              arr[i].signinTime = arr[i].signinTime.split(' ')[1];
            }
          }
          shopInfo.region = shopInfo.region.replace(/,/g, '');
          that.setData({
            id: sid,
            shopInfo: shopInfo,
            devicelist: res.data.data.devices
          })
        }
        wx.hideLoading();
      },
      fail: function () {
        wx.hideLoading();
      }
    })
  },

  shopMapHandle: function () {
    var shopInfo = this.data.shopInfo;
    var latitude = shopInfo.latitude;
    var longitude = shopInfo.longitude;
    wx.openLocation({
      longitude: Number(longitude),
      latitude: Number(latitude),
      name: shopInfo.name,
      address: shopInfo.region + shopInfo.address
    })
  }
})
