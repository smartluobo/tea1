// pages/usrcenter/index.js
const app = getApp();
var userInfo = app.globalData.userInfo ? app.globalData.userInfo : {};
Page({

  /**
   * 页面的初始数据
   */
  data: {
    phone:"",
    usrImg:"../../assets/img/default_pic.png"
  },
  tosignlist: function () {
    wx.switchTab({
      url: '/pages/signlist/signlist',
    })
  },
  signout: function () {
    wx.showModal({
      title: '',
      content: '确认退出登录？',
      success: function (res) {
        if (res.confirm) {
          //调用退出登录接口
          wx.setStorageSync('token', "");
          wx.setStorageSync('phone', "");
          /* wx.setStorageSync('openid', "");
          wx.clearStorageSync();
          wx.redirectTo({
            url: '../checkphone/index',
          })
          */
          wx.reLaunch({
            url: '../checkphone/index'
          })

        } else if (res.cancel) {

        }
      }
    })
  },
  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    this.setData({
      phone: wx.getStorageSync("phone").replace(/^(\d{3})\d{4}(\d{4})$/, "$1****$2"),
      usrImg: userInfo.avatarUrl || "../../assets/img/default_pic.png"
    })
  }
})
