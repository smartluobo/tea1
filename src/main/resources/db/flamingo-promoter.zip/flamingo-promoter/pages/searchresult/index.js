import { parseQueryString, isEmptyStr } from "../../utils/util";
const app = getApp();
Page({
  /**
   * 页面的初始数据
   */
  data: {
    shoplist: [],
    shopName: "",
    page: {},
    token: wx.getStorageSync("token"),
    show: true,
    nolist: false,
    errortext: '未找到相关店铺',
    isConnected: true
  },
  filterShop: function (e) {
    var word = e.detail.value.trim();
    this.setData({
      shopName: word,
    });

    if (word.length > 0) {
      this.getShopList();
    } else {
      this.setData({
        shoplist: [],
        nolist: false,
      });
    }
  },
  toSearch: function (e) {
    wx.navigateTo({
      url: '/pages/searchresult/index'
    })
  },
  toBack: function (e) {
    wx.navigateBack({
      delta: 1
      /*url: '/pages/shoplist/index'*/
    })
  },
  scantoactive: function () {
    // 只允许从相机扫码，不能相册扫码
    wx.scanCode({
      onlyFromCamera: true,
      success: (res) => {
        var path = parseQueryString(res.result);
        var type = path.type;//二维码参数 type active激活设备 tosign签到
        delete path.type;
        if (type == "tosign") {
          wx.request({
            url: app.globalData.hostUrl + '3m/signin/signin',
            data:
            {
              deviceNum: path.deviceNum,
              validTime: path.validTime,
              token: wx.getStorageSync("token")
            }
            ,
            success: function (res) {
              if (res.data) {
                var signed = "";
                if (res.data.status == 203) {
                  //二维码失效
                  wx.showToast({
                    title: '二维码已失效！',
                    icon: "error",
                    duration: 1500
                  });
                  return;
                }
                if (res.data.status == 200) {
                  signed = 0
                } else if (res.data.status == 305) {
                  signed = 1
                }
                wx.navigateTo({
                  url: '../sign/index?deviceNum=' + path.deviceNum + "&signed=" + signed
                })
              }
            }
          })
        } else {
          wx.showToast({
            title: '无法识别二维码！',
            icon: "none",
            duration: 1500
          })
        }
      },
      fail: function (e) {
        wx.showToast({
          title: '无法识别二维码！',
          icon: "none",
          duration: 1500
        })
      }
    })
  },
  getShopList: function () {
    var that = this;
    var shopName = that.data.shopName;
    if (!app.globalData.isConnected) {
      wx.showToast({
        title: '网络无反应\r\n请检查网络设置',
        icon: "none",
        duration: 1500,
      });
      return;
    }
    if (isEmptyStr(shopName)) {
      return;
    }
    wx.showToast({
      title: '查询中',
      icon: "loading"
    })
    wx.request({
      url: app.globalData.hostUrl + '3m/shopInfo/list',
      data: {
        token: wx.getStorageSync("token"),
        page: that.data.page,
        shopName: that.data.shopName
      },
      success: function (res) {
        if (res.data && res.data.status == 200) {
          var shoplist = res.data.data.data;
          for (var i = 0; i < shoplist.length; i++) {
            shoplist[i].region = shoplist[i].region.replace(/,/g, '');
          }
          that.setData({
            shoplist: shoplist,
            nolist: (shoplist.length == 0)
          })
        }
      },
      fail: function () {
        that.setData({
          shoplist: [],
          nolist: true,
        })
      },
      complete: function () {
        wx.hideToast();  //隐藏Toast
      }
    })
  },
  toShop: function (e) {
    var id = e.currentTarget.dataset.index;
    console.log(id);
    wx.navigateTo({
      url: '../shopdetail/index?id=' + id
    })
  },
  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    this.getNetworkTypeInfo();
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {
    var sessionId = wx.getStorageSync('token');
    var newUrl = '/pages/checkphone/index';
    var that = this;
    if (!sessionId) {
      // 登录
      wx.login({
        success: res => {
          // 发送 res.code 到后台换取 openId, sessionKey, unionId
          wx.request({
            url: app.globalData.hostUrl + '3m/login/getOpenid',
            data: {
              code: res.code,
              type: app.globalData.type
            },
            success: function (res) {
              if (res.data && res.data.status == 200) {
                //执行成功
                app.globalData.openid = res.data.data;
                wx.setStorageSync('openid', res.data.data);
                wx.redirectTo({
                  url: newUrl
                });
              }
            }
          })
        }
      })
    } else {
      that.setData({
        show: false
      })
    }
  },

  getNetworkTypeInfo: function () {
    var that = this;
    wx.getNetworkType({
      success(res) {
        const networkType = res.networkType
        if (networkType == 'none') {
          that.setData({ isConnected: false });
        } else {
          that.setData({ isConnected: true });
        }
      },
      fail(res) {
        that.setData({ isConnected: false });
      }
    })
    wx.onNetworkStatusChange(function (res) {
      that.setData({ isConnected: res.isConnected })
      if (res.isConnected) {
        that.getShopList();
      }
    })
  }
})
