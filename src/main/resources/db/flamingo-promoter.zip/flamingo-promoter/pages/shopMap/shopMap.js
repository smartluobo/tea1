const app = getApp();
Page({
  data: {
    markers: [{
      iconPath: "/assets/img/loca_focus.png",
      id: 0,
      latitude: 0,
      longitude: 0,
      width: 26,
      height: 26,
      label: {
        content: "",
        textAlign: "center",
        color: "#F62F5E"
      }
    }],
    latitude: 0,
    longitude: 0,
    screenHeight: 0

  },

  onLoad: function (options) {
    this.getScreenWidth();
    this.getShopInfo();
  },
  getShopInfo: function () {
    var that = this;
    wx.getStorage({
      key: 'shopInfo',
      success(res) {
        var shopInfo = res.data;
        var latitude = shopInfo.latitude;
        var longitude = shopInfo.longitude;
        shopInfo.region = shopInfo.region.replace(/,/g, '');
        wx.openLocation({
          longitude: Number(longitude),
          latitude: Number(latitude),
          name: shopInfo.name,
          address: shopInfo.region + shopInfo.address
        })

      }
    })
  },
  buildData: function (latitude, longitude) {
    var markers = this.data.markers;
    markers[0].latitude = latitude;
    markers[0].longitude = longitude;
    console.log(markers)
    this.setData({
      markers: markers,
      latitude: latitude,
      longitude: longitude,
    })
  },

  getScreenWidth: function () {
    var that = this;
    wx.getSystemInfo({
      success: function (res) {
        that.setData({ screenWidth: res.windowWidth, screenHeight: res.windowHeight });
      }
    })
  },
})
