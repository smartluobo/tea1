const app = getApp();
import { formateDate } from "../../utils/util"
Page({
  data: {
    signInType: 0, // 0:未签到 1: 进行中  2: 已签到
    shoplist: [],
    allShopList: [],
    noSignShopList: [],
    nowSignShopList: [],
    signShopList: [],
    signDate: "",
    page: { pageNo: 0, pageSize: 100 },
    winWidth: 0,
    winHeight: 0,
    isConnected: true
  },

  /**
   * 生命周期 函数--监听页面加载
   */
  onLoad: function (options) {
    this.getSignList(0,"");
    this.initSystemInfo();
    this.getNetworkTypeInfo();
  },
  initSystemInfo: function () {
    var that = this;
    wx.getSystemInfo({
      success: function (res) {
        that.setData({
          pixelRatio: res.pixelRatio,
          winWidth: res.windowWidth,
          winHeight: res.windowHeight
        });
      }
    });
  },

  /**
   * 菜单改变切换状态
   */
  tapChange: function (e) {
    var that = this;
    var signInType = e.detail.current;
    var signDate = this.data.signDate;
    that.setData({ signInType: signInType });
    this.getSignList(signInType, signDate);
  },

  swichNav: function (e) {
    var that = this;
    if (that.data.signInType == e.currentTarget.dataset.current) {
      return;
    } else {
      var current = e.currentTarget.dataset.current;
      var signInType = e.currentTarget.dataset.signintype;
      that.setData({
        currentTab: parseInt(current),
        signInType: parseInt(signInType),
      });
    }
  },

  /**
   * 选择日期
   */
  dateChange(e) {
    var signDate = e.detail.value;
    var signInType = this.data.signInType;
    this.setData({
      signDate: signDate
    })
    this.getSignList(signInType, signDate);
  },


  getDetailSignHandle: function (event) {
    var shopid = event.currentTarget.dataset.index;
    var signDate = this.data.signDate;
    wx.navigateTo({
      url: '../signdetail/index?id=' + shopid + "&signDate=" + signDate
    })
  },

 /**
  * 获取签到数据
  */
  getSignList: function (signInType, signDate) {
    var that = this;
    var signInType = signInType - 1;
    if (signDate == "") {
      signDate = formateDate(new Date(), false);
      this.setData({ signDate: signDate });
    }
    wx.showLoading();
    wx.request({
      url: app.globalData.hostUrl + '3m/shopInfo/signInList',
      data: {
        token: wx.getStorageSync("token"),
        signInType: signInType < 0 ? "" : signInType,
        page: that.data.page,
        signDate: signDate
      },
      method: "post",
      success: function (res) {
        if (res.data && res.data.status == 200) {
          var data = res.data.data.data || [];
          var totalRecord = res.data.data.iTotalRecords
          for (var i = 0; i < data.length; i++) {
            data[i].region = data[i].region.replace(/,/g, '');
          }
          if (signInType == -1) {
            that.setData({
              allShopList: data,
            })
          } else if (signInType == 0) {
            that.setData({
              noSignShopList: data
            })
          } else if (signInType == 1) {
            that.setData({
              nowSignShopList: data
            })
          } else if (signInType == 2) {
            that.setData({
              signShopList: data
            })
          }

        }
        wx.hideLoading();
      },
      fail: function () {
        wx.hideLoading();
      }
    })
  },

  /**
   * 监听网络状态
   */
  getNetworkTypeInfo: function () {
    var that = this;
    wx.getNetworkType({
      success(res) {
        const networkType = res.networkType
        if (networkType == 'none') {
          that.setData({ isConnected: false });
        } else {
          that.setData({ isConnected: true });
        }
      },
      fail(res) {
        that.setData({ isConnected: false });
      }
    })
    wx.onNetworkStatusChange(function (res) {
      that.setData({ isConnected: res.isConnected })
      if (res.isConnected) {
        that.getSignList();
      }
    })
  }
})
